from __future__ import annotations

import copy
from typing import Dict, List

import numpy as np
import torch
import torch.nn as nn

from .utils import compute_layerwise_drift, model_to_vector, vector_to_model


def aggregate_historical_direction(args: Dict, historical_updates: List[torch.Tensor]) -> torch.Tensor:
    num_rounds = len(historical_updates)
    gamma = args["hist_gamma"]

    weights = np.array([gamma ** (num_rounds - 1 - t) for t in range(num_rounds)], dtype=np.float32)
    weights = weights / weights.sum()

    agg = None
    for weight, delta_vec in zip(weights, historical_updates):
        delta_vec = delta_vec.float()
        agg = delta_vec * weight if agg is None else agg + delta_vec * weight

    return agg


def hgpga_attack(
    args: Dict,
    serving_model: nn.Module,
    historical_updates: List[torch.Tensor],
    variant: str = "V2",
) -> nn.Module:
    witness_model = copy.deepcopy(serving_model).to(args["device"])
    witness_model.eval()

    hist_dir = aggregate_historical_direction(args, historical_updates)

    if variant == "V1":
        attack_dir = -historical_updates[-1].float()
    elif variant == "V2":
        attack_dir = -hist_dir.float()
    elif variant == "V3":
        attack_dir = -torch.sign(hist_dir).float()
    else:
        raise ValueError(f"Unknown attack variant: {variant}")

    attack_dir = attack_dir.to(args["device"])
    if args["normalize_attack_dir"]:
        attack_dir = attack_dir / (attack_dir.norm(p=2) + 1e-12)

    theta_srv = model_to_vector(serving_model).to(args["device"])
    theta = theta_srv.clone()

    for _ in range(args["attack_steps"]):
        theta = theta + args["attack_lr"] * attack_dir
        diff = theta - theta_srv
        diff_norm = diff.norm(p=2)
        if diff_norm > args["attack_eps"]:
            diff = diff / (diff_norm + 1e-12) * args["attack_eps"]
            theta = theta_srv + diff

    vector_to_model(theta, witness_model)
    print("[Server Action] >>> HG-PGA completed.")
    return witness_model


def compute_stealth_metrics(serving_model: nn.Module, witness_model: nn.Module, hist_dir: torch.Tensor) -> Dict[str, float]:
    delta = model_to_vector(witness_model) - model_to_vector(serving_model)
    norm_val = delta.norm(p=2).item()

    hist_dir = hist_dir.to(delta.device)
    cos_val = torch.dot(delta, hist_dir) / (delta.norm(p=2) * hist_dir.norm(p=2) + 1e-12)
    max_mu, max_sigma = compute_layerwise_drift(serving_model, witness_model)

    return {
        "delta_norm": norm_val,
        "delta_cos_hist": cos_val.item(),
        "max_mu_drift": max_mu,
        "max_sigma_drift": max_sigma,
    }
