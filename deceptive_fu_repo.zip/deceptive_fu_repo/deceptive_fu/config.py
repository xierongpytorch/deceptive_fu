from __future__ import annotations

import copy
from typing import Any, Dict, List

import torch


DEFAULT_ARGS: Dict[str, Any] = {
    "num_users": 5,
    "frac": 1.0,
    "epochs": 1,
    "local_bs": 32,
    "lr": 0.01,
    "momentum": 0.9,
    "rounds": 10,
    "device": torch.device("cuda" if torch.cuda.is_available() else "cpu"),
    "seed": 42,
    "dataset_name": "cifar10",
    "data_dir": "./cifar10_images_32",
    "num_classes": 10,
    "image_size": 32,
    "test_dir_name": "test",
    "backbone": "simple_cnn",
    "aggregation_rule": "fedavg",
    "fedprox_mu": 0.01,
    "feddyn_alpha": 0.001,
    "feddyn_server_lr": 1.0,
    "moon_mu": 1.0,
    "moon_temperature": 0.5,
    "alpha": 0.5,
    "target_client_idx": 0,
    "val_ratio": 0.2,
    "baseline_verifier_acc_threshold": 20.0,
    "baseline_verifier_drop_threshold": 8.0,
    "attack_variant": "V3",
    "attack_lr": 0.3,
    "attack_steps": 10,
    "attack_eps": 2.0,
    "hist_gamma": 0.9,
    "normalize_attack_dir": True,
    "cp_alpha": 0.1,
    "cp_beta": 0.1,
    "cp_resamples": 300,
    "use_label_conditional_cp": True,
    "use_representation_evidence": True,
    "cp_score_mode": "logprob",
    "cp_set_size_normalize": True,
    "conditional_label_mode": "topk_mass",
    "conditional_topk_labels": 20,
    "conditional_mass_ratio": 0.8,
    "min_label_count_for_conditional": 20,
    "conditional_weight_mode": "harmonic",
    "conditional_soft_margin": 1.15,
    "rep_metric": "cosine",
    "rep_stat": "centroid",
    "rep_resamples": 200,
    "verifier_mode": "enhanced_joint",
    "fu_pipeline_mode": "naive_unlearn",
    "retain_repair_rounds": 5,
    "retain_repair_lr_scale": 0.5,
    "ga_steps": 3,
    "ga_lr": 0.01,
    "repair_steps_after_ga": 3,
    "unlearning_fail_gap_threshold": 1.0,
    "run_game_analysis": True,
    "game_iterations": 50,
}


DATASET_PRESETS: List[Dict[str, Any]] = [
    {
        "dataset_name": "cifar10",
        "data_dir": "./cifar10_images_32",
        "num_classes": 10,
        "image_size": 32,
        "test_dir_name": "test",
        "rounds": 20,
        "epochs": 1,
    },
    {
        "dataset_name": "cifar100",
        "data_dir": "./cifar100_images_32",
        "num_classes": 100,
        "image_size": 32,
        "test_dir_name": "test",
        "rounds": 100,
        "epochs": 1,
    },
    {
        "dataset_name": "tiny_imagenet_200",
        "data_dir": "../data/tiny-imagenet-200/tiny-imagenet-200",
        "num_classes": 200,
        "image_size": 64,
        "test_dir_name": "val_reorg",
        "rounds": 100,
        "epochs": 1,
    },
]


def make_args(**overrides: Any) -> Dict[str, Any]:
    args = copy.deepcopy(DEFAULT_ARGS)
    args.update(overrides)
    return args
