from __future__ import annotations

import os
from typing import Dict, Iterable, Set

import numpy as np
from torch.utils.data import Dataset
from torchvision import datasets, transforms


class DatasetSplit(Dataset):
    def __init__(self, dataset: Dataset, idxs: Iterable[int]):
        self.dataset = dataset
        self.idxs = list(idxs)

    def __len__(self) -> int:
        return len(self.idxs)

    def __getitem__(self, item: int):
        image, label = self.dataset[self.idxs[item]]
        return image, label


def get_dataset(args: Dict) -> tuple[Dataset, Dataset]:
    dataset_name = args["dataset_name"].lower()
    data_dir = args["data_dir"]
    image_size = args.get("image_size", 32)
    test_dir_name = args.get("test_dir_name", "test")

    transform = transforms.Compose(
        [
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
        ]
    )

    if dataset_name in {"cifar10", "cifar100", "tiny_imagenet_200"}:
        train_path = os.path.join(data_dir, "train")
        test_path = os.path.join(data_dir, test_dir_name)
        train_dataset = datasets.ImageFolder(root=train_path, transform=transform)
        test_dataset = datasets.ImageFolder(root=test_path, transform=transform)
        return train_dataset, test_dataset

    raise ValueError(f"Unsupported dataset_name: {dataset_name}")


def split_data(dataset: Dataset, num_users: int, seed: int, alpha: float) -> Dict[int, Set[int]]:
    np.random.seed(seed)

    if hasattr(dataset, "targets"):
        labels = np.array(dataset.targets)
    elif hasattr(dataset, "samples"):
        labels = np.array([label for _, label in dataset.samples])
    else:
        raise ValueError("Dataset must expose either 'targets' or 'samples'.")

    num_classes = len(np.unique(labels))
    dict_users = {i: [] for i in range(num_users)}

    for class_id in range(num_classes):
        idx_k = np.where(labels == class_id)[0]
        np.random.shuffle(idx_k)

        proportions = np.random.dirichlet(np.repeat(alpha, num_users))
        proportions = np.round(proportions * len(idx_k)).astype(int)
        proportions[-1] = len(idx_k) - proportions[:-1].sum()

        cur = 0
        for user_id in range(num_users):
            dict_users[user_id].extend(idx_k[cur : cur + proportions[user_id]])
            cur += proportions[user_id]

    print(f"\n>>> (Dirichlet Alpha = {alpha}) <<<")
    for user_id in range(num_users):
        dict_users[user_id] = set(dict_users[user_id])
        client_labels = labels[list(dict_users[user_id])]
        unique, counts = np.unique(client_labels, return_counts=True)
        dist_str = ", ".join([f"{u}:{c}" for u, c in zip(unique, counts)])
        print(f"Client {user_id} ({len(dict_users[user_id])}): {dist_str}")
    print("=" * 60 + "\n")

    return dict_users
