from __future__ import annotations

import copy
import time
from typing import Dict

import numpy as np
import torch
from tqdm import tqdm

from .attacks import aggregate_historical_direction, compute_stealth_metrics, hgpga_attack
from .data import get_dataset, split_data
from .federated import FedAvg, LocalUpdate, retrain_without_client, test_local_accuracy, test_model
from .game import simulate_reduced_game
from .models import build_model, initialize_lazy_layers
from .pipelines import build_fu_pipeline_model
from .utils import model_distance, parameter_delta_from_state_dicts, set_seed
from .verifiers import baseline_point_metric_verifier, run_verifier_by_mode


def run_one_experiment(args: Dict) -> Dict:
    set_seed(args["seed"])
    train_dataset, test_dataset = get_dataset(args)
    dict_users = split_data(train_dataset, args["num_users"], args["seed"], args["alpha"])

    target_all_idxs = list(dict_users[args["target_client_idx"]])
    target_labels = np.array([train_dataset[idx][1] for idx in target_all_idxs])

    unique_classes, counts = np.unique(target_labels, return_counts=True)
    sorted_classes = unique_classes[np.argsort(-counts)]
    num_forget_classes = max(1, len(sorted_classes) // 2)
    forget_classes = set(sorted_classes[:num_forget_classes])
    retain_classes = set(sorted_classes[num_forget_classes:])

    idxs_forget_pool = [idx for idx in target_all_idxs if train_dataset[idx][1] in forget_classes]
    idxs_retain_pool = [idx for idx in target_all_idxs if train_dataset[idx][1] in retain_classes]

    rng = np.random.default_rng(args["seed"])
    rng.shuffle(idxs_forget_pool)
    rng.shuffle(idxs_retain_pool)

    calib_in_ratio = 0.15
    num_calib_in = max(10, int(len(idxs_forget_pool) * calib_in_ratio))
    num_calib_in = min(num_calib_in, len(idxs_forget_pool) // 3)

    idxs_calib_in = idxs_forget_pool[:num_calib_in]
    idxs_forget = idxs_forget_pool[num_calib_in:]

    target_calib_total = max(20, int(len(target_all_idxs) * args["val_ratio"]))
    num_calib_out = max(0, target_calib_total - len(idxs_calib_in))
    num_calib_out = min(num_calib_out, len(idxs_retain_pool))

    idxs_calib_out = idxs_retain_pool[:num_calib_out]
    idxs_calib = idxs_calib_in + idxs_calib_out

    remaining_retain = idxs_retain_pool[num_calib_out:]
    if len(idxs_calib) < 20 and remaining_retain:
        extra = min(20 - len(idxs_calib), len(remaining_retain))
        idxs_calib.extend(remaining_retain[:extra])

    print(f"[Split] Forget classes: {sorted(list(forget_classes))}")
    print(
        f"[Split] #forget = {len(idxs_forget)}, #calib_in = {len(idxs_calib_in)}, "
        f"#calib_out = {len(idxs_calib_out)}, #calib_total = {len(idxs_calib)}"
    )

    dict_users[args["target_client_idx"]] = set(idxs_forget)

    net_glob = build_model(args)
    initialize_lazy_layers(net_glob, train_dataset, args["device"], args.get("backbone", "simple_cnn"))
    net_glob.eval()
    with torch.no_grad():
        dummy_x, _ = train_dataset[0]
        _ = net_glob(dummy_x.unsqueeze(0).to(args["device"]))
    net_glob.train()
    w_glob = copy.deepcopy(net_glob.state_dict())

    historical_target_updates = []

    for round_idx in range(args["rounds"]):
        print(f"\n--- Round {round_idx + 1}/{args['rounds']} ---")
        w_locals = []

        for idx in tqdm(list(range(args["num_users"])), desc="Client Training"):
            local = LocalUpdate(args=args, dataset=train_dataset, idxs=dict_users[idx])
            net_local = build_model(args)
            initialize_lazy_layers(net_local, train_dataset, args["device"], args.get("backbone", "simple_cnn"))
            net_local.load_state_dict(copy.deepcopy(w_glob))

            w_local, _ = local.train(net_local)
            w_locals.append(copy.deepcopy(w_local))

            if idx == args["target_client_idx"]:
                delta_vec = parameter_delta_from_state_dicts(w_before=w_glob, w_after=w_local, model_template=net_glob)
                historical_target_updates.append(delta_vec)

        w_glob = FedAvg(w_locals)
        net_glob.load_state_dict(w_glob)
        acc = test_model(net_glob, test_dataset, args)
        print(f"Round {round_idx + 1} Global Test Acc: {acc:.2f}%")

    serving_model = copy.deepcopy(net_glob)
    serving_acc = test_model(serving_model, test_dataset, args)

    start_ref = time.time()
    ref_model = retrain_without_client(args, train_dataset, dict_users, args["target_client_idx"])
    ref_time = time.time() - start_ref
    ref_acc = test_model(ref_model, test_dataset, args)
    ref_local_acc = test_local_accuracy(ref_model, train_dataset, idxs_forget, args)

    pipeline_model = build_fu_pipeline_model(
        args=args,
        train_dataset=train_dataset,
        dict_users=dict_users,
        serving_model=serving_model,
        ref_model=ref_model,
        target_client_idx=args["target_client_idx"],
        idxs_forget=idxs_forget,
    )

    pipeline_acc = test_model(pipeline_model, test_dataset, args)
    pipeline_forget_acc = test_local_accuracy(pipeline_model, train_dataset, idxs_forget, args)
    acc_before = pipeline_forget_acc

    start_attack = time.time()
    witness_model = hgpga_attack(args, pipeline_model, historical_target_updates, variant=args["attack_variant"])
    attack_time = time.time() - start_attack

    witness_acc_global = test_model(witness_model, test_dataset, args)
    acc_witness_forget = test_local_accuracy(witness_model, train_dataset, idxs_forget, args)

    baseline_pass = baseline_point_metric_verifier(
        acc_before=acc_before,
        acc_after=acc_witness_forget,
        drop_threshold=args["baseline_verifier_drop_threshold"],
    )

    srv_ref_gap = model_distance(pipeline_model, ref_model)
    unlearning_fail = srv_ref_gap > args["unlearning_fail_gap_threshold"]
    hist_dir = aggregate_historical_direction(args, historical_target_updates).to(args["device"])
    stealth_metrics = compute_stealth_metrics(pipeline_model, witness_model, hist_dir)

    start_cp_ref = time.time()
    cp_ref = run_verifier_by_mode(
        args=args,
        model=ref_model,
        dataset=train_dataset,
        idxs_calib=idxs_calib,
        idxs_forget=idxs_forget,
        acc_before=pipeline_forget_acc,
        acc_after=ref_local_acc,
    )
    cp_ref_time = time.time() - start_cp_ref

    start_cp_wit = time.time()
    cp_wit = run_verifier_by_mode(
        args=args,
        model=witness_model,
        dataset=train_dataset,
        idxs_calib=idxs_calib,
        idxs_forget=idxs_forget,
        acc_before=acc_before,
        acc_after=acc_witness_forget,
    )
    cp_wit_time = time.time() - start_cp_wit

    joint_success = baseline_pass and unlearning_fail

    if args.get("run_game_analysis", False):
        delta_u_drop = max(acc_before - ref_local_acc, 1e-6)
        penalty_range = np.linspace(10, 300, 20)
        _ = [
            simulate_reduced_game(L_pen_val=pen, Delta_U_drop_val=delta_u_drop, use_admm=True, iterations=args["game_iterations"])
            for pen in penalty_range
        ]

    result = {
        "seed": args["seed"],
        "dataset_name": args["dataset_name"],
        "backbone": args["backbone"],
        "serving_acc": float(serving_acc),
        "ref_acc": float(ref_acc),
        "ref_local_acc": float(ref_local_acc),
        "witness_acc_global": float(witness_acc_global),
        "acc_before": float(acc_before),
        "acc_witness_forget": float(acc_witness_forget),
        "baseline_pass": bool(baseline_pass),
        "srv_ref_gap": float(srv_ref_gap),
        "unlearning_fail": bool(unlearning_fail),
        "joint_success": bool(joint_success),
        "cp_ref_accept": bool(cp_ref["accept"]),
        "cp_wit_accept": bool(cp_wit["accept"]),
        "cp_ref_delta_size": float(cp_ref["delta_size"]),
        "cp_ref_delta_ks": float(cp_ref["delta_ks"]),
        "cp_wit_delta_size": float(cp_wit["delta_size"]),
        "cp_wit_delta_ks": float(cp_wit["delta_ks"]),
        "attack_time": float(attack_time),
        "ref_time": float(ref_time),
        "cp_ref_time": float(cp_ref_time),
        "cp_wit_time": float(cp_wit_time),
        "delta_norm": float(stealth_metrics["delta_norm"]),
        "delta_cos_hist": float(stealth_metrics["delta_cos_hist"]),
        "max_mu_drift": float(stealth_metrics["max_mu_drift"]),
        "max_sigma_drift": float(stealth_metrics["max_sigma_drift"]),
        "cp_ref_delta_rep": float(cp_ref.get("delta_rep", 0.0)),
        "cp_ref_tau_rep": float(cp_ref.get("tau_rep", 0.0)),
        "cp_wit_delta_rep": float(cp_wit.get("delta_rep", 0.0)),
        "cp_wit_tau_rep": float(cp_wit.get("tau_rep", 0.0)),
        "cp_ref_valid_labels": int(cp_ref.get("num_valid_labels_cp", 0)),
        "cp_wit_valid_labels": int(cp_wit.get("num_valid_labels_cp", 0)),
        "cp_accept_raw": float(cp_wit.get("cp_accept_raw", 0.0)),
        "rep_accept_raw": float(cp_wit.get("rep_accept_raw", 0.0)),
        "rep_override_accept": float(cp_wit.get("rep_override_accept", 0.0)),
        "ks_ratio": float(cp_wit.get("ks_ratio", 0.0)),
        "verifier_mode": str(args.get("verifier_mode", "enhanced_joint")),
        "fu_pipeline_mode": str(args.get("fu_pipeline_mode", "naive_unlearn")),
        "pipeline_acc": float(pipeline_acc),
        "pipeline_forget_acc": float(pipeline_forget_acc),
        "verifier_ref_accept": bool(cp_ref["accept"]),
        "verifier_wit_accept": bool(cp_wit["accept"]),
    }
    return result
