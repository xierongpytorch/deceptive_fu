from __future__ import annotations

import copy
from typing import Dict, Iterable, List, Tuple

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from .data import DatasetSplit
from .models import build_model, initialize_lazy_layers


class LocalUpdate:
    def __init__(self, args: Dict, dataset, idxs: Iterable[int]):
        self.args = args
        self.ldr_train = DataLoader(
            DatasetSplit(dataset, idxs),
            batch_size=args["local_bs"],
            shuffle=True,
        )
        self.loss_func = nn.CrossEntropyLoss()

    def train(self, net: nn.Module) -> Tuple[Dict[str, torch.Tensor], float]:
        net.train()
        optimizer = torch.optim.SGD(
            net.parameters(),
            lr=self.args["lr"],
            momentum=self.args["momentum"],
        )
        epoch_loss: List[float] = []

        for _ in range(self.args["epochs"]):
            batch_loss: List[float] = []
            for images, labels in self.ldr_train:
                images = images.to(self.args["device"])
                labels = labels.to(self.args["device"])

                optimizer.zero_grad()
                outputs = net(images)
                loss = self.loss_func(outputs, labels)
                loss.backward()
                optimizer.step()
                batch_loss.append(loss.item())

            epoch_loss.append(sum(batch_loss) / max(len(batch_loss), 1))

        return copy.deepcopy(net.state_dict()), sum(epoch_loss) / max(len(epoch_loss), 1)


# Keep the original function name for minimal migration cost.
def FedAvg(weights: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
    avg_weights = copy.deepcopy(weights[0])
    for key in avg_weights.keys():
        for i in range(1, len(weights)):
            avg_weights[key] += weights[i][key]
        avg_weights[key] = avg_weights[key] / len(weights)
    return avg_weights


def test_model(net: nn.Module, dataset, args: Dict) -> float:
    net.eval()
    loader = DataLoader(dataset, batch_size=args["local_bs"], shuffle=False)
    correct, total = 0, 0
    with torch.no_grad():
        for images, labels in loader:
            images = images.to(args["device"])
            labels = labels.to(args["device"])
            outputs = net(images)
            pred = outputs.argmax(dim=1)
            total += labels.size(0)
            correct += (pred == labels).sum().item()
    return 100.0 * correct / max(total, 1)


def test_local_accuracy(model: nn.Module, dataset, idxs: Iterable[int], args: Dict) -> float:
    model.eval()
    loader = DataLoader(DatasetSplit(dataset, idxs), batch_size=args["local_bs"], shuffle=False)
    correct, total = 0, 0
    with torch.no_grad():
        for images, labels in loader:
            images = images.to(args["device"])
            labels = labels.to(args["device"])
            outputs = model(images)
            pred = outputs.argmax(dim=1)
            total += labels.size(0)
            correct += (pred == labels).sum().item()
    return 100.0 * correct / max(total, 1)


def retrain_without_client(args: Dict, train_dataset, dict_users, target_client_idx: int) -> nn.Module:
    retained_users = [i for i in range(args["num_users"]) if i != target_client_idx]

    model = build_model(args)
    initialize_lazy_layers(model, train_dataset, args["device"], args.get("backbone", "simple_cnn"))
    w_glob = copy.deepcopy(model.state_dict())

    for _ in range(args["rounds"]):
        w_locals = []
        for idx in retained_users:
            local = LocalUpdate(args=args, dataset=train_dataset, idxs=dict_users[idx])
            net_local = build_model(args)
            initialize_lazy_layers(net_local, train_dataset, args["device"], args.get("backbone", "simple_cnn"))
            net_local.load_state_dict(w_glob)

            w_local, _ = local.train(net_local)
            w_locals.append(copy.deepcopy(w_local))

        w_glob = FedAvg(w_locals)
        model.load_state_dict(w_glob)

    return model
