from __future__ import annotations

import numpy as np


def simulate_reduced_game(L_pen_val: float, Delta_U_drop_val: float, use_admm: bool = True, iterations: int = 50):
    lambda_cp = 5.0
    V_P_val, L_P_val = 100.0, 50.0
    kappa, gamma = 20.0, 10.0
    rho_val = 0.5 if use_admm else 0.0

    e_S, tau_C = 1.0, 0.1
    multiplier = 0.0
    residuals = []

    for _ in range(iterations):
        dpi_dtau = lambda_cp * e_S * np.exp(-lambda_cp * e_S * tau_C)
        grad_C = dpi_dtau * (V_P_val + L_P_val) - kappa * tau_C
        tau_C = np.clip(tau_C + 0.05 * grad_C, 0.01, 1.0)

        dpi_des = lambda_cp * tau_C * np.exp(-lambda_cp * e_S * tau_C)
        grad_S = Delta_U_drop_val - gamma * e_S - dpi_des * L_pen_val
        e_S = np.clip(e_S + 0.02 * (grad_S - rho_val * multiplier), 0.0, 1.0)

        g_val = dpi_dtau * (V_P_val + L_P_val) - kappa * tau_C
        multiplier += rho_val * g_val
        residuals.append(abs(g_val))

    return e_S, tau_C, residuals
