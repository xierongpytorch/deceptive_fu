from __future__ import annotations

from typing import Dict, Tuple

import torch
import torch.nn as nn
from torchvision import models


class SimpleCNN(nn.Module):
    def __init__(self, num_classes: int = 10):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
            nn.Conv2d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
        )
        self.classifier: nn.Module | None = None
        self.num_classes = num_classes

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.features(x)
        x = x.view(x.size(0), -1)

        if self.classifier is None:
            n_features = x.shape[1]
            self.classifier = nn.Sequential(
                nn.Linear(n_features, 64),
                nn.ReLU(),
                nn.Linear(64, self.num_classes),
            ).to(x.device)

        return self.classifier(x)


def build_resnet18(num_classes: int = 10) -> nn.Module:
    model = models.resnet18()
    model.fc = nn.Linear(model.fc.in_features, num_classes)
    return model


def build_resnet34(num_classes: int = 10) -> nn.Module:
    model = models.resnet34()
    model.fc = nn.Linear(model.fc.in_features, num_classes)
    return model


def build_model(args: Dict) -> nn.Module:
    backbone = args.get("backbone", "simple_cnn").lower()

    if backbone == "simple_cnn":
        model = SimpleCNN(num_classes=args["num_classes"])
    elif backbone == "resnet18":
        model = build_resnet18(num_classes=args["num_classes"])
    elif backbone == "resnet34":
        model = build_resnet34(num_classes=args["num_classes"])
    else:
        raise ValueError(f"Unknown backbone: {backbone}")

    return model.to(args["device"])


def initialize_lazy_layers(model: nn.Module, dataset, device, backbone: str | None = None) -> None:
    if backbone is not None and backbone.lower() != "simple_cnn":
        return

    dummy_img, _ = dataset[0]
    dummy_batch = dummy_img.unsqueeze(0).to(device)

    was_training = model.training
    model.eval()
    with torch.no_grad():
        model(dummy_batch)
    if was_training:
        model.train()


def extract_features(model: nn.Module, x: torch.Tensor, backbone_name: str) -> torch.Tensor:
    backbone = backbone_name.lower()

    if backbone == "simple_cnn":
        x = model.features(x)
        return x.view(x.size(0), -1)

    if backbone in {"resnet18", "resnet34"}:
        x = model.conv1(x)
        x = model.bn1(x)
        x = model.relu(x)
        x = model.maxpool(x)
        x = model.layer1(x)
        x = model.layer2(x)
        x = model.layer3(x)
        x = model.layer4(x)
        x = model.avgpool(x)
        return torch.flatten(x, 1)

    raise ValueError(f"Unsupported backbone for feature extraction: {backbone}")


def forward_with_features(model: nn.Module, x: torch.Tensor, backbone_name: str) -> Tuple[torch.Tensor, torch.Tensor]:
    feat = extract_features(model, x, backbone_name)
    backbone = backbone_name.lower()

    if backbone == "simple_cnn":
        if model.classifier is None:
            _ = model(x)
            feat = extract_features(model, x, backbone_name)
        logits = model.classifier(feat)
    elif backbone in {"resnet18", "resnet34"}:
        logits = model.fc(feat)
    else:
        raise ValueError(f"Unsupported backbone for forward_with_features: {backbone}")

    return logits, feat
