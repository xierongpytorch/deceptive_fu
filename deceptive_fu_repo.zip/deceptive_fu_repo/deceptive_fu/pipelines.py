from __future__ import annotations

import copy
from typing import Dict, Iterable

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from .data import DatasetSplit
from .federated import FedAvg, LocalUpdate
from .models import build_model, initialize_lazy_layers


def build_finetune_retain_model(args: Dict, train_dataset, dict_users, base_model: nn.Module, target_client_idx: int) -> nn.Module:
    retained_users = [i for i in range(args["num_users"]) if i != target_client_idx]
    model = copy.deepcopy(base_model).to(args["device"])
    repair_args = copy.deepcopy(args)
    repair_args["lr"] = args["lr"] * args.get("retain_repair_lr_scale", 0.5)
    repair_rounds = args.get("retain_repair_rounds", 5)
    w_glob = copy.deepcopy(model.state_dict())

    for _ in range(repair_rounds):
        w_locals = []
        for idx in retained_users:
            local = LocalUpdate(args=repair_args, dataset=train_dataset, idxs=dict_users[idx])
            net_local = build_model(repair_args)
            initialize_lazy_layers(net_local, train_dataset, repair_args["device"], repair_args.get("backbone", "simple_cnn"))
            net_local.load_state_dict(copy.deepcopy(w_glob))
            w_local, _ = local.train(net_local)
            w_locals.append(copy.deepcopy(w_local))
        w_glob = FedAvg(w_locals)

    model.load_state_dict(w_glob)
    return model


def gradient_ascent_on_forget_set(args: Dict, model: nn.Module, dataset, idxs_forget: Iterable[int]) -> nn.Module:
    ga_model = copy.deepcopy(model).to(args["device"])
    ga_model.train()

    loader = DataLoader(DatasetSplit(dataset, idxs_forget), batch_size=args["local_bs"], shuffle=True)
    optimizer = torch.optim.SGD(ga_model.parameters(), lr=args.get("ga_lr", 0.01), momentum=args["momentum"])
    loss_func = nn.CrossEntropyLoss()

    step_count = 0
    for images, labels in loader:
        images = images.to(args["device"])
        labels = labels.to(args["device"])
        optimizer.zero_grad()
        outputs = ga_model(images)
        loss = loss_func(outputs, labels)
        (-loss).backward()
        optimizer.step()
        step_count += 1
        if step_count >= args.get("ga_steps", 3):
            break

    return ga_model


def repair_after_ga(args: Dict, train_dataset, dict_users, model: nn.Module, target_client_idx: int) -> nn.Module:
    retained_users = [i for i in range(args["num_users"]) if i != target_client_idx]
    repair_model = copy.deepcopy(model).to(args["device"])
    w_glob = copy.deepcopy(repair_model.state_dict())

    for _ in range(args.get("repair_steps_after_ga", 3)):
        w_locals = []
        for idx in retained_users:
            local = LocalUpdate(args=args, dataset=train_dataset, idxs=dict_users[idx])
            net_local = build_model(args)
            initialize_lazy_layers(net_local, train_dataset, args["device"], args.get("backbone", "simple_cnn"))
            net_local.load_state_dict(copy.deepcopy(w_glob))
            w_local, _ = local.train(net_local)
            w_locals.append(copy.deepcopy(w_local))
        w_glob = FedAvg(w_locals)

    repair_model.load_state_dict(w_glob)
    return repair_model


def build_ga_forget_then_repair_model(args: Dict, train_dataset, dict_users, base_model: nn.Module, target_client_idx: int, idxs_forget):
    ga_model = gradient_ascent_on_forget_set(args, base_model, train_dataset, idxs_forget)
    return repair_after_ga(args, train_dataset, dict_users, ga_model, target_client_idx)


def build_fu_pipeline_model(args: Dict, train_dataset, dict_users, serving_model: nn.Module, ref_model: nn.Module, target_client_idx: int, idxs_forget):
    mode = args.get("fu_pipeline_mode", "naive_unlearn")

    if mode == "retrain":
        return copy.deepcopy(ref_model)
    if mode == "naive_unlearn":
        return copy.deepcopy(serving_model)
    if mode == "finetune_retain":
        return build_finetune_retain_model(args, train_dataset, dict_users, serving_model, target_client_idx)
    if mode == "ga_forget_then_repair":
        return build_ga_forget_then_repair_model(args, train_dataset, dict_users, serving_model, target_client_idx, idxs_forget)

    raise ValueError(f"Unknown fu_pipeline_mode: {mode}")
