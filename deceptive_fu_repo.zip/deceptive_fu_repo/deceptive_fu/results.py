from __future__ import annotations

import csv
from typing import Dict, List

import numpy as np


def summarize_results(all_results: List[Dict], tag: str = "Repeated-Seeds Summary") -> None:
    def mean_std(key: str):
        vals = np.array([r[key] for r in all_results], dtype=np.float32)
        return float(vals.mean()), float(vals.std())

    joint_rate = np.mean([r["joint_success"] for r in all_results])
    honest_accept_rate = np.mean([r["verifier_ref_accept"] for r in all_results])
    witness_reject_rate = np.mean([not r["verifier_wit_accept"] for r in all_results])

    print("\n" + "=" * 70)
    print(tag)
    print("=" * 70)
    print(f"Num runs: {len(all_results)}")
    print(f"Joint Deceptive-FU Success Rate: {joint_rate:.3f}")
    print(f"Verifier Honest Accept Rate: {honest_accept_rate:.3f}")
    print(f"Verifier Witness Reject Rate: {witness_reject_rate:.3f}")

    for key in [
        "serving_acc",
        "ref_acc",
        "witness_acc_global",
        "acc_before",
        "acc_witness_forget",
        "srv_ref_gap",
        "cp_ref_delta_size",
        "cp_ref_delta_ks",
        "cp_ref_delta_rep",
        "cp_wit_delta_size",
        "cp_wit_delta_ks",
        "cp_wit_delta_rep",
        "attack_time",
        "ref_time",
        "cp_ref_time",
        "cp_wit_time",
    ]:
        mean_value, std_value = mean_std(key)
        print(f"{key:25s}: {mean_value:.4f} ± {std_value:.4f}")

    print("=" * 70)


def save_results_to_csv(all_results: List[Dict], filepath: str = "repeated_seeds_results.csv") -> None:
    if not all_results:
        return
    keys = list(all_results[0].keys())
    with open(filepath, "w", newline="", encoding="utf-8") as file_obj:
        writer = csv.DictWriter(file_obj, fieldnames=keys)
        writer.writeheader()
        writer.writerows(all_results)
    print(f"[Saved] results -> {filepath}")


def summarize_backbone_group(all_results: List[Dict]) -> List[Dict]:
    grouped = {}
    for result in all_results:
        grouped.setdefault(result["backbone"], []).append(result)

    summary_rows = []
    for backbone, results in grouped.items():
        row = {"backbone": backbone, "num_runs": len(results)}
        for key in [
            "serving_acc",
            "ref_acc",
            "witness_acc_global",
            "acc_before",
            "acc_witness_forget",
            "srv_ref_gap",
            "cp_ref_delta_size",
            "cp_ref_delta_ks",
            "cp_wit_delta_size",
            "cp_wit_delta_ks",
            "attack_time",
            "ref_time",
            "cp_ref_time",
            "cp_wit_time",
            "delta_norm",
            "delta_cos_hist",
            "max_mu_drift",
            "max_sigma_drift",
        ]:
            vals = np.array([r[key] for r in results], dtype=np.float32)
            row[f"{key}_mean"] = float(vals.mean())
            row[f"{key}_std"] = float(vals.std())

        row["joint_success_rate"] = float(np.mean([r["joint_success"] for r in results]))
        row["cp_ref_accept_rate"] = float(np.mean([r["cp_ref_accept"] for r in results]))
        row["cp_wit_reject_rate"] = float(np.mean([not r["cp_wit_accept"] for r in results]))
        summary_rows.append(row)

    return summary_rows


def summarize_dataset_group(all_results: List[Dict]) -> List[Dict]:
    grouped = {}
    for result in all_results:
        grouped.setdefault(result["dataset_name"], []).append(result)

    summary_rows = []
    for dataset_name, results in grouped.items():
        row = {"dataset_name": dataset_name, "num_runs": len(results)}
        for key in [
            "serving_acc",
            "ref_acc",
            "witness_acc_global",
            "acc_before",
            "acc_witness_forget",
            "srv_ref_gap",
            "cp_ref_delta_size",
            "cp_ref_delta_ks",
            "cp_ref_delta_rep",
            "cp_wit_delta_size",
            "cp_wit_delta_ks",
            "cp_wit_delta_rep",
            "attack_time",
            "ref_time",
            "cp_ref_time",
            "cp_wit_time",
            "delta_norm",
            "delta_cos_hist",
            "max_mu_drift",
            "max_sigma_drift",
            "cp_accept_raw",
            "rep_accept_raw",
            "rep_override_accept",
            "ks_ratio",
        ]:
            vals = np.array([r[key] for r in results], dtype=np.float32)
            row[f"{key}_mean"] = float(vals.mean())
            row[f"{key}_std"] = float(vals.std())

        row["joint_success_rate"] = float(np.mean([r["joint_success"] for r in results]))
        row["cp_ref_accept_rate"] = float(np.mean([r["cp_ref_accept"] for r in results]))
        row["cp_wit_reject_rate"] = float(np.mean([not r["cp_wit_accept"] for r in results]))
        summary_rows.append(row)

    return summary_rows


def summarize_experiment_group(all_results: List[Dict]) -> List[Dict]:
    grouped = {}
    for result in all_results:
        key = (result["dataset_name"], result["verifier_mode"], result["fu_pipeline_mode"])
        grouped.setdefault(key, []).append(result)

    summary_rows = []
    for key, results in grouped.items():
        dataset_name, verifier_mode, fu_pipeline_mode = key
        row = {
            "dataset_name": dataset_name,
            "verifier_mode": verifier_mode,
            "fu_pipeline_mode": fu_pipeline_mode,
            "num_runs": len(results),
        }

        for key2 in [
            "serving_acc",
            "ref_acc",
            "pipeline_acc",
            "witness_acc_global",
            "acc_before",
            "acc_witness_forget",
            "srv_ref_gap",
            "attack_time",
            "ref_time",
            "delta_norm",
            "delta_cos_hist",
            "max_mu_drift",
            "max_sigma_drift",
        ]:
            vals = np.array([r[key2] for r in results], dtype=np.float32)
            row[f"{key2}_mean"] = float(vals.mean())
            row[f"{key2}_std"] = float(vals.std())

        row["joint_success_rate"] = float(np.mean([r["joint_success"] for r in results]))
        row["verifier_ref_accept_rate"] = float(np.mean([r["verifier_ref_accept"] for r in results]))
        row["verifier_wit_reject_rate"] = float(np.mean([not r["verifier_wit_accept"] for r in results]))
        summary_rows.append(row)

    return summary_rows
