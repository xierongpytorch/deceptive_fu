from __future__ import annotations

import copy
import random
from typing import Dict

import numpy as np
import torch
import torch.nn as nn


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def state_dict_to_param_vector(state_dict: Dict[str, torch.Tensor], model_template: nn.Module) -> torch.Tensor:
    temp_model = copy.deepcopy(model_template).to("cpu")
    temp_model.load_state_dict(state_dict, strict=True)
    return nn.utils.parameters_to_vector(temp_model.parameters()).detach().cpu()


def parameter_delta_from_state_dicts(
    w_before: Dict[str, torch.Tensor],
    w_after: Dict[str, torch.Tensor],
    model_template: nn.Module,
) -> torch.Tensor:
    vec_before = state_dict_to_param_vector(w_before, model_template)
    vec_after = state_dict_to_param_vector(w_after, model_template)
    return (vec_after - vec_before).detach().cpu()


def model_to_vector(model: nn.Module) -> torch.Tensor:
    return nn.utils.parameters_to_vector(model.parameters()).detach()


def vector_to_model(vec: torch.Tensor, model: nn.Module) -> None:
    nn.utils.vector_to_parameters(vec, model.parameters())


def get_param_list(model: nn.Module):
    return [p for p in model.parameters() if p.requires_grad]


def clone_param_vector(model: nn.Module) -> torch.Tensor:
    return nn.utils.parameters_to_vector(get_param_list(model)).detach().clone()


def model_distance(model1: nn.Module, model2: nn.Module) -> float:
    v1 = model_to_vector(model1)
    v2 = model_to_vector(model2)
    return torch.norm(v1 - v2, p=2).item()


def compute_layerwise_drift(serving_model: nn.Module, witness_model: nn.Module) -> tuple[float, float]:
    max_mu = 0.0
    max_sigma = 0.0
    with torch.no_grad():
        for (_, p_s), (_, p_w) in zip(serving_model.named_parameters(), witness_model.named_parameters()):
            if p_s.ndim == 0:
                continue
            mu_s = p_s.mean().item()
            mu_w = p_w.mean().item()
            sigma_s = p_s.std().item()
            sigma_w = p_w.std().item()
            max_mu = max(max_mu, abs(mu_w - mu_s))
            max_sigma = max(max_sigma, abs(sigma_w - sigma_s))
    return max_mu, max_sigma
