from __future__ import annotations

from typing import Dict, Iterable, Tuple

import numpy as np
import torch
from scipy.stats import ks_2samp
from torch.utils.data import DataLoader

from .data import DatasetSplit
from .models import forward_with_features
from .utils import model_to_vector


def get_nonconformity_scores_with_labels(model, loader, args: Dict) -> Tuple[np.ndarray, np.ndarray]:
    model.eval()
    scores = []
    labels_all = []
    score_mode = args.get("cp_score_mode", "logprob")

    with torch.no_grad():
        for images, labels in loader:
            images = images.to(args["device"])
            labels = labels.to(args["device"])

            logits = model(images)
            probs = torch.softmax(logits, dim=1)
            true_probs = probs[torch.arange(len(labels)), labels]

            if score_mode == "prob":
                batch_scores = 1.0 - true_probs
            elif score_mode == "logprob":
                batch_scores = -torch.log(true_probs + 1e-12)
            else:
                raise ValueError(f"Unsupported cp_score_mode: {score_mode}")

            scores.extend(batch_scores.detach().cpu().numpy().tolist())
            labels_all.extend(labels.detach().cpu().numpy().tolist())

    return np.array(scores, dtype=np.float32), np.array(labels_all, dtype=np.int64)


def group_scores_by_label(scores: np.ndarray, labels: np.ndarray) -> Dict[int, np.ndarray]:
    grouped: Dict[int, list[float]] = {}
    for score, label in zip(scores, labels):
        grouped.setdefault(int(label), []).append(float(score))
    return {label: np.array(values, dtype=np.float32) for label, values in grouped.items()}


def compute_prediction_set_sizes_normalized(
    model,
    loader,
    q_hat: float,
    num_classes: int,
    device,
    args: Dict,
    normalize: bool = True,
) -> float:
    model.eval()
    all_sizes = []
    with torch.no_grad():
        for images, _ in loader:
            images = images.to(device)
            logits = model(images)
            probs = torch.softmax(logits, dim=1)

            if args.get("cp_score_mode", "logprob") == "logprob":
                threshold = float(np.exp(-q_hat))
            elif args.get("cp_score_mode", "logprob") == "prob":
                threshold = float(1.0 - q_hat)
            else:
                raise ValueError("Unsupported cp_score_mode.")

            threshold = max(float(threshold), 0.0)
            sizes = (probs >= threshold).sum(dim=1).float()
            if normalize:
                sizes = sizes / float(num_classes)
            all_sizes.extend(sizes.detach().cpu().numpy().tolist())

    return float(np.mean(all_sizes))


def get_features_and_labels(model, loader, args: Dict) -> Tuple[np.ndarray, np.ndarray]:
    model.eval()
    feats = []
    labels_all = []

    with torch.no_grad():
        for images, labels in loader:
            images = images.to(args["device"])
            labels = labels.to(args["device"])
            _, feat = forward_with_features(model, images, args["backbone"])
            feats.append(feat.detach().cpu())
            labels_all.append(labels.detach().cpu())

    feats_np = torch.cat(feats, dim=0).numpy().astype(np.float32)
    labels_np = torch.cat(labels_all, dim=0).numpy().astype(np.int64)
    return feats_np, labels_np


def compute_label_centroids(features: np.ndarray, labels: np.ndarray, min_count: int = 1) -> Dict[int, np.ndarray]:
    centroids: Dict[int, np.ndarray] = {}
    for label in np.unique(labels):
        idx = np.where(labels == label)[0]
        if len(idx) >= min_count:
            centroids[int(label)] = features[idx].mean(axis=0)
    return centroids


def select_conditional_labels(calib_group: Dict[int, np.ndarray], forget_group: Dict[int, np.ndarray], args: Dict) -> list[int]:
    min_count = args.get("min_label_count_for_conditional", 20)
    candidate_labels = []
    label_sizes = {}

    for label in sorted(set(calib_group.keys()) & set(forget_group.keys())):
        n_cal = len(calib_group[label])
        n_for = len(forget_group[label])
        if n_cal < min_count or n_for < min_count:
            continue
        candidate_labels.append(label)
        label_sizes[label] = n_for

    if not candidate_labels:
        return []

    mode = args.get("conditional_label_mode", "topk_mass")
    if mode == "all_valid":
        return candidate_labels
    if mode == "topk_count":
        topk = args.get("conditional_topk_labels", 20)
        return sorted(candidate_labels, key=lambda y: label_sizes[y], reverse=True)[:topk]
    if mode == "topk_mass":
        mass_ratio = args.get("conditional_mass_ratio", 0.8)
        sorted_labels = sorted(candidate_labels, key=lambda y: label_sizes[y], reverse=True)
        total_mass = sum(label_sizes[y] for y in sorted_labels)
        kept = []
        running = 0
        for label in sorted_labels:
            kept.append(label)
            running += label_sizes[label]
            if running / max(total_mass, 1) >= mass_ratio:
                break
        return kept

    raise ValueError(f"Unknown conditional_label_mode: {mode}")


def get_label_weight(n_cal: int, n_for: int, mode: str = "harmonic") -> float:
    if mode == "uniform":
        return 1.0
    if mode == "min":
        return float(min(n_cal, n_for))
    if mode == "harmonic":
        return float(2.0 * n_cal * n_for / max(n_cal + n_for, 1e-12))
    raise ValueError(f"Unknown conditional_weight_mode: {mode}")


def calibrate_label_conditional_null_thresholds(args: Dict, model, dataset, idxs_calib: Iterable[int]):
    calib_indices = np.array(list(idxs_calib))
    rng = np.random.default_rng(args["seed"])

    delta_size_null = []
    delta_ks_null = []
    delta_mean_null = []

    for _ in range(args["cp_resamples"]):
        rng.shuffle(calib_indices)
        mid = len(calib_indices) // 2
        idxs_1 = calib_indices[:mid]
        idxs_2 = calib_indices[mid:]

        loader1 = DataLoader(DatasetSplit(dataset, idxs_1), batch_size=args["local_bs"], shuffle=False)
        loader2 = DataLoader(DatasetSplit(dataset, idxs_2), batch_size=args["local_bs"], shuffle=False)

        scores1, labels1 = get_nonconformity_scores_with_labels(model, loader1, args)
        scores2, labels2 = get_nonconformity_scores_with_labels(model, loader2, args)

        group1 = group_scores_by_label(scores1, labels1)
        group2 = group_scores_by_label(scores2, labels2)

        selected_labels = select_conditional_labels(group1, group2, args)
        if not selected_labels:
            continue

        ks_vals, mean_vals, weights = [], [], []
        for label in selected_labels:
            n1, n2 = len(group1[label]), len(group2[label])
            weight = get_label_weight(n1, n2, args.get("conditional_weight_mode", "harmonic"))
            ks_stat, _ = ks_2samp(group1[label], group2[label])
            delta_mean = abs(float(np.mean(group1[label])) - float(np.mean(group2[label])))

            ks_vals.append(float(ks_stat))
            mean_vals.append(delta_mean)
            weights.append(weight)

        weights_np = np.array(weights, dtype=np.float32)
        weights_np = weights_np / max(weights_np.sum(), 1e-12)

        agg_ks = float(np.sum(weights_np * np.array(ks_vals, dtype=np.float32)))
        agg_mean = float(np.sum(weights_np * np.array(mean_vals, dtype=np.float32)))

        n = len(scores1)
        val = np.ceil((n + 1) * (1 - args["cp_alpha"])) / n
        val = float(np.clip(val, 0.0, 1.0))
        q_hat = np.quantile(scores1, val)

        size1 = compute_prediction_set_sizes_normalized(
            model, loader1, q_hat, args["num_classes"], args["device"], args=args, normalize=args.get("cp_set_size_normalize", True)
        )
        size2 = compute_prediction_set_sizes_normalized(
            model, loader2, q_hat, args["num_classes"], args["device"], args=args, normalize=args.get("cp_set_size_normalize", True)
        )

        delta_size_null.append(abs(size1 - size2))
        delta_ks_null.append(agg_ks)
        delta_mean_null.append(agg_mean)

    if not delta_ks_null:
        return float("inf"), float("inf"), float("inf")

    tau_size = float(np.quantile(delta_size_null, 1.0 - args["cp_beta"]))
    tau_ks = float(np.quantile(delta_ks_null, 1.0 - args["cp_beta"]))
    tau_mean = float(np.quantile(delta_mean_null, 1.0 - args["cp_beta"]))
    return tau_size, tau_ks, tau_mean


def compute_label_spreads(features: np.ndarray, labels: np.ndarray, centroids: Dict[int, np.ndarray], metric: str = "l2", min_count: int = 1):
    spreads = {}
    for label in np.unique(labels):
        label = int(label)
        idx = np.where(labels == label)[0]
        if len(idx) < min_count or label not in centroids:
            continue

        feat_y = features[idx]
        centroid = centroids[label]

        if metric == "l2":
            dist = np.linalg.norm(feat_y - centroid[None, :], axis=1)
            spreads[label] = float(np.mean(dist))
        elif metric == "cosine":
            norms_feat = np.linalg.norm(feat_y, axis=1) + 1e-12
            norm_c = np.linalg.norm(centroid) + 1e-12
            sims = np.sum(feat_y * centroid[None, :], axis=1) / (norms_feat * norm_c)
            spreads[label] = float(np.mean(1.0 - sims))
        else:
            raise ValueError(f"Unsupported metric: {metric}")
    return spreads


def compute_representation_shift(features_a: np.ndarray, labels_a: np.ndarray, features_b: np.ndarray, labels_b: np.ndarray, args: Dict):
    min_count = args.get("min_label_count_for_conditional", 20)
    metric = args.get("rep_metric", "cosine")

    cent_a = compute_label_centroids(features_a, labels_a, min_count=min_count)
    cent_b = compute_label_centroids(features_b, labels_b, min_count=min_count)

    shared = sorted(set(cent_a.keys()) & set(cent_b.keys()))
    if not shared:
        return float("inf"), float("inf"), float("inf"), 0

    spread_a = compute_label_spreads(features_a, labels_a, cent_a, metric=metric, min_count=min_count)
    spread_b = compute_label_spreads(features_b, labels_b, cent_b, metric=metric, min_count=min_count)

    centroid_dists = []
    spread_diffs = []
    weights = []

    for label in shared:
        idx_a = np.where(labels_a == label)[0]
        idx_b = np.where(labels_b == label)[0]
        weight = get_label_weight(len(idx_a), len(idx_b), args.get("conditional_weight_mode", "harmonic"))
        weights.append(weight)

        a = cent_a[label]
        b = cent_b[label]
        if metric == "cosine":
            na = np.linalg.norm(a) + 1e-12
            nb = np.linalg.norm(b) + 1e-12
            centroid_dist = 1.0 - float(np.dot(a, b) / (na * nb))
        else:
            centroid_dist = float(np.linalg.norm(a - b))
        centroid_dists.append(centroid_dist)
        spread_diffs.append(abs(spread_a.get(label, 0.0) - spread_b.get(label, 0.0)))

    weights_np = np.array(weights, dtype=np.float32)
    weights_np = weights_np / max(weights_np.sum(), 1e-12)

    delta_centroid = float(np.sum(weights_np * np.array(centroid_dists, dtype=np.float32)))
    delta_spread = float(np.sum(weights_np * np.array(spread_diffs, dtype=np.float32)))
    delta_rep_joint = 0.7 * delta_centroid + 0.3 * delta_spread
    return delta_rep_joint, delta_centroid, delta_spread, len(shared)


def calibrate_representation_null_threshold(args: Dict, model, dataset, idxs_calib: Iterable[int]):
    calib_indices = np.array(list(idxs_calib))
    rng = np.random.default_rng(args["seed"])

    rep_joint_null = []
    rep_centroid_null = []
    rep_spread_null = []

    for _ in range(args.get("rep_resamples", 200)):
        rng.shuffle(calib_indices)
        mid = len(calib_indices) // 2
        idxs_1 = calib_indices[:mid]
        idxs_2 = calib_indices[mid:]

        loader1 = DataLoader(DatasetSplit(dataset, idxs_1), batch_size=args["local_bs"], shuffle=False)
        loader2 = DataLoader(DatasetSplit(dataset, idxs_2), batch_size=args["local_bs"], shuffle=False)

        feat1, lab1 = get_features_and_labels(model, loader1, args)
        feat2, lab2 = get_features_and_labels(model, loader2, args)

        delta_joint, delta_centroid, delta_spread, num_shared = compute_representation_shift(feat1, lab1, feat2, lab2, args)
        if num_shared > 0 and np.isfinite(delta_joint):
            rep_joint_null.append(delta_joint)
            rep_centroid_null.append(delta_centroid)
            rep_spread_null.append(delta_spread)

    if not rep_joint_null:
        return float("inf"), float("inf"), float("inf")

    tau_joint = float(np.quantile(rep_joint_null, 1.0 - args["cp_beta"]))
    tau_centroid = float(np.quantile(rep_centroid_null, 1.0 - args["cp_beta"]))
    tau_spread = float(np.quantile(rep_spread_null, 1.0 - args["cp_beta"]))
    return tau_joint, tau_centroid, tau_spread


def label_conditional_conformal_verification(args: Dict, model, dataset, idxs_calib: Iterable[int], idxs_forget: Iterable[int]) -> Dict:
    calib_loader = DataLoader(DatasetSplit(dataset, idxs_calib), batch_size=args["local_bs"], shuffle=False)
    forget_loader = DataLoader(DatasetSplit(dataset, idxs_forget), batch_size=args["local_bs"], shuffle=False)

    calib_scores, calib_labels = get_nonconformity_scores_with_labels(model, calib_loader, args)
    forget_scores, forget_labels = get_nonconformity_scores_with_labels(model, forget_loader, args)

    calib_group = group_scores_by_label(calib_scores, calib_labels)
    forget_group = group_scores_by_label(forget_scores, forget_labels)
    selected_labels = select_conditional_labels(calib_group, forget_group, args)

    ks_vals, mean_vals, weights = [], [], []
    for label in selected_labels:
        n_cal = len(calib_group[label])
        n_for = len(forget_group[label])
        ks_stat, _ = ks_2samp(calib_group[label], forget_group[label])
        delta_mean = abs(float(np.mean(calib_group[label])) - float(np.mean(forget_group[label])))
        weight = get_label_weight(n_cal, n_for, args.get("conditional_weight_mode", "harmonic"))

        ks_vals.append(float(ks_stat))
        mean_vals.append(delta_mean)
        weights.append(weight)

    weights_np = np.array(weights, dtype=np.float32)
    weights_np = weights_np / max(weights_np.sum(), 1e-12)
    delta_ks_cond = float(np.sum(weights_np * np.array(ks_vals, dtype=np.float32))) if len(weights_np) else float("inf")
    delta_mean_cond = float(np.sum(weights_np * np.array(mean_vals, dtype=np.float32))) if len(weights_np) else float("inf")

    n = len(calib_scores)
    val = np.ceil((n + 1) * (1 - args["cp_alpha"])) / n
    val = float(np.clip(val, 0.0, 1.0))
    q_hat = np.quantile(calib_scores, val)

    calib_set_size = compute_prediction_set_sizes_normalized(
        model, calib_loader, q_hat, args["num_classes"], args["device"], args=args, normalize=args.get("cp_set_size_normalize", True)
    )
    forget_set_size = compute_prediction_set_sizes_normalized(
        model, forget_loader, q_hat, args["num_classes"], args["device"], args=args, normalize=args.get("cp_set_size_normalize", True)
    )
    delta_size = abs(forget_set_size - calib_set_size)

    tau_size, tau_ks, tau_mean = calibrate_label_conditional_null_thresholds(args, model, dataset, idxs_calib)
    accept = (delta_size <= tau_size) and (delta_ks_cond <= tau_ks)

    return {
        "accept": bool(accept),
        "delta_size": float(delta_size),
        "delta_ks": float(delta_ks_cond),
        "delta_mean_cond": float(delta_mean_cond),
        "tau_size": float(tau_size),
        "tau_ks": float(tau_ks),
        "tau_mean": float(tau_mean),
        "q_hat": float(q_hat),
        "calib_set_size": float(calib_set_size),
        "forget_set_size": float(forget_set_size),
        "num_valid_labels": int(len(selected_labels)),
    }


def representation_evidence_verification(args: Dict, model, dataset, idxs_calib: Iterable[int], idxs_forget: Iterable[int]) -> Dict:
    calib_loader = DataLoader(DatasetSplit(dataset, idxs_calib), batch_size=args["local_bs"], shuffle=False)
    forget_loader = DataLoader(DatasetSplit(dataset, idxs_forget), batch_size=args["local_bs"], shuffle=False)

    feat_cal, lab_cal = get_features_and_labels(model, calib_loader, args)
    feat_for, lab_for = get_features_and_labels(model, forget_loader, args)

    delta_rep, delta_centroid, delta_spread, num_shared = compute_representation_shift(feat_cal, lab_cal, feat_for, lab_for, args)
    if num_shared == 0 or not np.isfinite(delta_rep):
        return {
            "accept": False,
            "delta_rep": float("inf"),
            "delta_rep_centroid": float("inf"),
            "delta_rep_spread": float("inf"),
            "tau_rep": float("inf"),
            "tau_rep_centroid": float("inf"),
            "tau_rep_spread": float("inf"),
            "num_valid_labels": 0,
        }

    tau_rep, tau_centroid, tau_spread = calibrate_representation_null_threshold(args, model, dataset, idxs_calib)
    accept = delta_rep <= tau_rep

    return {
        "accept": bool(accept),
        "delta_rep": float(delta_rep),
        "delta_rep_centroid": float(delta_centroid),
        "delta_rep_spread": float(delta_spread),
        "tau_rep": float(tau_rep),
        "tau_rep_centroid": float(tau_centroid),
        "tau_rep_spread": float(tau_spread),
        "num_valid_labels": int(num_shared),
    }


def enhanced_conformal_verification(args: Dict, model, dataset, idxs_calib: Iterable[int], idxs_forget: Iterable[int]) -> Dict:
    if args.get("use_label_conditional_cp", True):
        cp_result = label_conditional_conformal_verification(args, model, dataset, idxs_calib, idxs_forget)
    else:
        cp_result = conformal_prediction_verification(args, model, dataset, idxs_calib, idxs_forget)

    if args.get("use_representation_evidence", True):
        rep_result = representation_evidence_verification(args, model, dataset, idxs_calib, idxs_forget)
    else:
        rep_result = {"accept": True, "delta_rep": 0.0, "tau_rep": float("inf"), "num_valid_labels": 0}

    cp_accept = bool(cp_result["accept"])
    rep_accept = bool(rep_result["accept"])
    tau_ks = max(cp_result.get("tau_ks", 1e-12), 1e-12)
    ks_ratio = cp_result.get("delta_ks", float("inf")) / tau_ks
    soft_margin = args.get("conditional_soft_margin", 1.15)
    rep_override_accept = (ks_ratio <= soft_margin) and rep_accept
    joint_accept = (cp_accept and rep_accept) or ((not cp_accept) and rep_override_accept)

    return {
        "accept": bool(joint_accept),
        "delta_size": float(cp_result["delta_size"]),
        "delta_ks": float(cp_result["delta_ks"]),
        "tau_size": float(cp_result["tau_size"]),
        "tau_ks": float(cp_result["tau_ks"]),
        "q_hat": float(cp_result["q_hat"]),
        "calib_set_size": float(cp_result["calib_set_size"]),
        "forget_set_size": float(cp_result["forget_set_size"]),
        "delta_rep": float(rep_result["delta_rep"]),
        "tau_rep": float(rep_result["tau_rep"]),
        "delta_rep_centroid": float(rep_result.get("delta_rep_centroid", 0.0)),
        "delta_rep_spread": float(rep_result.get("delta_rep_spread", 0.0)),
        "tau_rep_centroid": float(rep_result.get("tau_rep_centroid", float("inf"))),
        "tau_rep_spread": float(rep_result.get("tau_rep_spread", float("inf"))),
        "cp_accept_raw": bool(cp_accept),
        "rep_accept_raw": bool(rep_accept),
        "rep_override_accept": bool(rep_override_accept),
        "ks_ratio": float(ks_ratio),
        "num_valid_labels_cp": int(cp_result.get("num_valid_labels", 0)),
        "num_valid_labels_rep": int(rep_result.get("num_valid_labels", 0)),
    }


def get_nonconformity_scores(model, loader, device) -> np.ndarray:
    model.eval()
    scores = []
    with torch.no_grad():
        for images, labels in loader:
            images = images.to(device)
            labels = labels.to(device)
            logits = model(images)
            probs = torch.softmax(logits, dim=1)
            batch_scores = 1.0 - probs[torch.arange(len(labels)), labels]
            scores.extend(batch_scores.detach().cpu().numpy().tolist())
    return np.array(scores, dtype=np.float32)


def compute_prediction_set_sizes(model, loader, q_hat: float, num_classes: int, device) -> float:
    model.eval()
    all_sizes = []
    with torch.no_grad():
        for images, _ in loader:
            images = images.to(device)
            logits = model(images)
            probs = torch.softmax(logits, dim=1)
            sizes = (probs >= (1.0 - q_hat)).sum(dim=1)
            all_sizes.extend(sizes.detach().cpu().numpy().tolist())
    return float(np.mean(all_sizes))


def calibrate_null_thresholds(args: Dict, model, dataset, idxs_calib: Iterable[int]):
    calib_indices = np.array(list(idxs_calib))
    rng = np.random.default_rng(args["seed"])

    delta_size_null = []
    delta_ks_null = []
    for _ in range(args["cp_resamples"]):
        rng.shuffle(calib_indices)
        mid = len(calib_indices) // 2
        idxs_1 = calib_indices[:mid]
        idxs_2 = calib_indices[mid:]

        loader1 = DataLoader(DatasetSplit(dataset, idxs_1), batch_size=args["local_bs"], shuffle=False)
        loader2 = DataLoader(DatasetSplit(dataset, idxs_2), batch_size=args["local_bs"], shuffle=False)

        scores1 = get_nonconformity_scores(model, loader1, args["device"])
        scores2 = get_nonconformity_scores(model, loader2, args["device"])

        n = len(scores1)
        val = np.ceil((n + 1) * (1 - args["cp_alpha"])) / n
        val = float(np.clip(val, 0.0, 1.0))
        q_hat = np.quantile(scores1, val)

        size1 = compute_prediction_set_sizes(model, loader1, q_hat, args["num_classes"], args["device"])
        size2 = compute_prediction_set_sizes(model, loader2, q_hat, args["num_classes"], args["device"])
        delta_size_null.append(abs(size1 - size2))

        ks_stat, _ = ks_2samp(scores1, scores2)
        delta_ks_null.append(float(ks_stat))

    tau_size = float(np.quantile(delta_size_null, 1.0 - args["cp_beta"]))
    tau_ks = float(np.quantile(delta_ks_null, 1.0 - args["cp_beta"]))
    return tau_size, tau_ks


def conformal_prediction_verification(args: Dict, model, dataset, idxs_calib: Iterable[int], idxs_forget: Iterable[int]) -> Dict:
    calib_loader = DataLoader(DatasetSplit(dataset, idxs_calib), batch_size=args["local_bs"], shuffle=False)
    forget_loader = DataLoader(DatasetSplit(dataset, idxs_forget), batch_size=args["local_bs"], shuffle=False)

    calib_scores = get_nonconformity_scores(model, calib_loader, args["device"])
    forget_scores = get_nonconformity_scores(model, forget_loader, args["device"])

    n = len(calib_scores)
    val = np.ceil((n + 1) * (1 - args["cp_alpha"])) / n
    val = float(np.clip(val, 0.0, 1.0))
    q_hat = np.quantile(calib_scores, val)

    calib_set_size = compute_prediction_set_sizes(model, calib_loader, q_hat, args["num_classes"], args["device"])
    forget_set_size = compute_prediction_set_sizes(model, forget_loader, q_hat, args["num_classes"], args["device"])
    delta_size = abs(forget_set_size - calib_set_size)

    ks_stat, p_value = ks_2samp(calib_scores, forget_scores)
    tau_size, tau_ks = calibrate_null_thresholds(args, model, dataset, idxs_calib)
    accept = (delta_size <= tau_size) and (ks_stat <= tau_ks)

    return {
        "accept": bool(accept),
        "delta_size": float(delta_size),
        "delta_ks": float(ks_stat),
        "tau_size": float(tau_size),
        "tau_ks": float(tau_ks),
        "q_hat": float(q_hat),
        "calib_set_size": float(calib_set_size),
        "forget_set_size": float(forget_set_size),
        "ks_pvalue": float(p_value),
    }


def baseline_point_metric_verifier(acc_before: float, acc_after: float, drop_threshold: float) -> bool:
    return (acc_before - acc_after) >= drop_threshold


def compute_stealth_metrics(serving_model, witness_model, hist_dir):
    delta = model_to_vector(witness_model) - model_to_vector(serving_model)
    norm_val = delta.norm(p=2).item()
    hist_dir = hist_dir.to(delta.device)
    cos_val = torch.dot(delta, hist_dir) / (delta.norm(p=2) * hist_dir.norm(p=2) + 1e-12)
    return {
        "delta_norm": norm_val,
        "delta_cos_hist": cos_val.item(),
    }


def run_verifier_by_mode(args: Dict, model, dataset, idxs_calib, idxs_forget, acc_before=None, acc_after=None) -> Dict:
    mode = args.get("verifier_mode", "enhanced_joint")

    if mode == "baseline_drop":
        accept = baseline_point_metric_verifier(acc_before, acc_after, args["baseline_verifier_drop_threshold"])
        return {
            "accept": bool(accept),
            "delta_size": 0.0,
            "delta_ks": 0.0,
            "tau_size": 0.0,
            "tau_ks": 0.0,
            "q_hat": 0.0,
            "calib_set_size": 0.0,
            "forget_set_size": 0.0,
            "delta_rep": 0.0,
            "tau_rep": 0.0,
            "delta_rep_centroid": 0.0,
            "delta_rep_spread": 0.0,
            "tau_rep_centroid": 0.0,
            "tau_rep_spread": 0.0,
            "cp_accept_raw": bool(accept),
            "rep_accept_raw": True,
            "rep_override_accept": False,
            "ks_ratio": 0.0,
            "num_valid_labels_cp": 0,
            "num_valid_labels_rep": 0,
        }

    if mode == "cp_only":
        cp_result = conformal_prediction_verification(args, model, dataset, idxs_calib, idxs_forget)
        return {
            "accept": bool(cp_result["accept"]),
            "delta_size": float(cp_result["delta_size"]),
            "delta_ks": float(cp_result["delta_ks"]),
            "tau_size": float(cp_result["tau_size"]),
            "tau_ks": float(cp_result["tau_ks"]),
            "q_hat": float(cp_result["q_hat"]),
            "calib_set_size": float(cp_result["calib_set_size"]),
            "forget_set_size": float(cp_result["forget_set_size"]),
            "delta_rep": 0.0,
            "tau_rep": 0.0,
            "delta_rep_centroid": 0.0,
            "delta_rep_spread": 0.0,
            "tau_rep_centroid": 0.0,
            "tau_rep_spread": 0.0,
            "cp_accept_raw": bool(cp_result["accept"]),
            "rep_accept_raw": True,
            "rep_override_accept": False,
            "ks_ratio": 0.0,
            "num_valid_labels_cp": 0,
            "num_valid_labels_rep": 0,
        }

    if mode == "rep_only":
        rep_result = representation_evidence_verification(args, model, dataset, idxs_calib, idxs_forget)
        return {
            "accept": bool(rep_result["accept"]),
            "delta_size": 0.0,
            "delta_ks": 0.0,
            "tau_size": 0.0,
            "tau_ks": 0.0,
            "q_hat": 0.0,
            "calib_set_size": 0.0,
            "forget_set_size": 0.0,
            "delta_rep": float(rep_result["delta_rep"]),
            "tau_rep": float(rep_result["tau_rep"]),
            "delta_rep_centroid": float(rep_result.get("delta_rep_centroid", 0.0)),
            "delta_rep_spread": float(rep_result.get("delta_rep_spread", 0.0)),
            "tau_rep_centroid": float(rep_result.get("tau_rep_centroid", 0.0)),
            "tau_rep_spread": float(rep_result.get("tau_rep_spread", 0.0)),
            "cp_accept_raw": True,
            "rep_accept_raw": bool(rep_result["accept"]),
            "rep_override_accept": False,
            "ks_ratio": 0.0,
            "num_valid_labels_cp": 0,
            "num_valid_labels_rep": int(rep_result.get("num_valid_labels", 0)),
        }

    if mode == "enhanced_joint":
        joint_result = enhanced_conformal_verification(args, model, dataset, idxs_calib, idxs_forget)
        return {
            "accept": bool(joint_result["accept"]),
            "delta_size": float(joint_result["delta_size"]),
            "delta_ks": float(joint_result["delta_ks"]),
            "tau_size": float(joint_result["tau_size"]),
            "tau_ks": float(joint_result["tau_ks"]),
            "q_hat": float(joint_result["q_hat"]),
            "calib_set_size": float(joint_result["calib_set_size"]),
            "forget_set_size": float(joint_result["forget_set_size"]),
            "delta_rep": float(joint_result["delta_rep"]),
            "tau_rep": float(joint_result["tau_rep"]),
            "delta_rep_centroid": float(joint_result.get("delta_rep_centroid", 0.0)),
            "delta_rep_spread": float(joint_result.get("delta_rep_spread", 0.0)),
            "tau_rep_centroid": float(joint_result.get("tau_rep_centroid", 0.0)),
            "tau_rep_spread": float(joint_result.get("tau_rep_spread", 0.0)),
            "cp_accept_raw": bool(joint_result.get("cp_accept_raw", joint_result["accept"])),
            "rep_accept_raw": bool(joint_result.get("rep_accept_raw", True)),
            "rep_override_accept": bool(joint_result.get("rep_override_accept", False)),
            "ks_ratio": float(joint_result.get("ks_ratio", 0.0)),
            "num_valid_labels_cp": int(joint_result.get("num_valid_labels_cp", 0)),
            "num_valid_labels_rep": int(joint_result.get("num_valid_labels_rep", 0)),
        }

    raise ValueError(f"Unknown verifier_mode: {mode}")
